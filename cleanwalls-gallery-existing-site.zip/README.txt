CLEANWALLS GALLERY REPLACEMENT

This ZIP is designed to slot into your EXISTING GitHub Cleanwalls website.

Upload:
1. gallery.html  -> replace the existing gallery.html
2. images/       -> upload the whole images folder into the repository root

DO NOT replace:
- index.html
- style.css
- logo.svg
- sandblasting.html
- chemical-cleaning.html
- jet-washing.html
- reviews.html
- contact.html

The gallery page expects logo.svg and style.css to remain in the root of your existing repository.
